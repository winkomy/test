# WINKO quotation system — GitHub testing package

This folder is the clean deployment package. The application needs only `index.html`; styles, logo and application code are embedded. No 2D, 3D or Studio page is required. The Supabase library loads from its existing CDN and the backend remains hosted in Supabase.

## Upload and publish

1. Extract the testing ZIP.
2. Upload its contents to the root of your GitHub repository. Do not upload the ZIP itself, the surrounding project folder, historical backups, screenshots or Supabase source files.
3. In repository **Settings → Pages**, choose **Deploy from a branch**, select your upload branch and **/(root)**, then Save.
4. Open the HTTPS website URL shown by GitHub Pages, not the repository's file preview.

Official instructions: [Configure a GitHub Pages publishing source](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).

Use a private repository where your GitHub plan supports Pages for it. A private repository does not automatically make the published website private. Keep Supabase authentication and RLS enabled.

## Backend and testing scope

This package connects to the current company Supabase project. It is a frontend testing deployment, **not an isolated test database**: saving, submitting or approving quotations changes the existing company data. Use clearly labelled test records and authorized accounts.

Do not commit passwords, `.env` files, service-role keys, Microsoft secrets or Resend keys. `RESEND_API_KEY` stays in Supabase Edge Function secrets; this static package cannot deploy the email backend. The existing `quotation-email` function is deployed separately.

After the real HTTPS URL exists, check Supabase Auth URL configuration for any supported password-recovery/redirect flow. Configure the backend `WINKO_APP_URL` if you want email notifications to link to the hosted application. Do not use a local `file://` URL for email links.

## Hosted smoke-test checklist

- Sales and Main/Admin sign-in, invalid password, refresh and sign-out.
- Role-restricted navigation remains restricted.
- Create a labelled test quotation, save draft and reopen from customer/history.
- Verify tank inputs, BOM quantities, estimate and quotation preview.
- Submit once; confirm Pending Main Approval in the cloud and Main approval queue.
- Verify approval/return and historical snapshot reopening with authorized test accounts.
- Send a notification test from Main settings and confirm delivery.
- Check desktop/mobile navigation and browser console for errors.

Local packaging validation passed for 50 inline JavaScript scripts. Hosted workflow, email delivery and browser tests must still be performed after publication.
